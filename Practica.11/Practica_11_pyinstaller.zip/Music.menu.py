#Variables globales:
grupos = []
ciudades = []

def opcion1():     #Agregar grupos y/o solistas:
    seguir = True
    while seguir:
        nombre = input("Ingresa nombre del grupo o del solista: ")
        genero = input("Ingresa su género musical: ")
        integrantes = int(input("Ingresa el numero de integrantes: "))
        ciudadProx = input("En que ciudad se presentara proximamente: ")
        grupos.append((nombre, genero, integrantes, ciudadProx))
        opc = int(input("¿Desea seguir agregando grupos o solistas? (Seleccione un numero)\n1 - Si\n2- No\n=> "))
        print("")
        if opc == 2:
            seguir = False
    return grupos

def opcion2():     #Agregar ciudades a la lista
    seguir = True
    while seguir:
        ciudad = input("Ingrese la ciudad: ")
        pais = input("Ingrese el pais donde se encuentra la ciudad: ")
        ciudades.append((ciudad, pais))
        opc = int(input("¿Desea seguir agregando ciudades? (Seleccione un numero)\n1 - Si\n2- No\n=> "))
        print("")
        if opc == 2:
            seguir = False
    return ciudades
    
def opcion3():   #Dado un genero, mostrar ciudades donde se presentaran
    cities = []
    genero = input("Ingrese un genero: ")
    for x in range(len(grupos)-1):
        if genero == grupos[x][1]:
            cities.append(grupos[x][3])
    if cities:
        print("Habrá presentaciónes en las siguientes ciudades:", cities)
        input("")
    else:
        print("No hay presentaciones de este genero")
        input("")

def opcion4():   #Dada una ciudad, mostrar los nombres de los grupos o solistas que se presentaran
    nombres = []
    ciudad = input("Ingrese una ciudad: ")
    for x in range(len(grupos)-1):
        if ciudad == grupos[x][3]:
            nombres.append(grupos[x][0])
    if nombres:
        print("Se encontraron los siguientes nombres: ", nombres)
        input("")
    else:
        print("No se encontró ningun grupo ni solista")
        input("")

def opcion5():      #Dado un genero, mostrar los paises
    paises = []
    genero = input("Ingrese un genero: ")
    for x in range(len(grupos)-1):
        if genero == grupos[x][1]:
            for y in range(len(ciudades)-1):
                if grupos[x][3] == ciudades[y][0]:
                    paises.append(ciudades[y][1])
    if paises:
        print("Habrá presentaciones en los siguientes paises: ",paises)
        input("")
    else:
        print("No habra presentaciones")
        input("")

def opcion6():   #Dado un pais, mostrar nombres de grupos y solistas
    nombres = []
    pais = input("Ingrese un pais: ")
    for x in range(len(ciudades)-1):
        if pais == ciudades[x][1]:
            for y in range(len(grupos)-1):
                if ciudades[x][0] == grupos[y][3]:
                    nombres.append(grupos[y][0])
    if nombres:
        print("Los siguientes grupos se presentaran en el pais seleccionado: ", nombres)
        input("")
    else:
        print("No hay ningun grupo ni solista en este pais")
        input("")

#Main:
seguirMenu = True
while seguirMenu:
    print("""
    Seleccione una de las siguientes opciones:
    1- Agregar grupos o solistas.
    2- Agregar ciudades y paises.
    3- Dado un genero, mostrar ciudades donde se presentaran.
    4- Dada una ciudad, mostrar los nombres de los grupos o solistas que se presentaran.
    5- Dado un genero, mostrar los paises.
    6- Dado un pais, mostrar nombres de grupos y solistas.
    7- Salir.
    """)
    opcion = int(input("=> "))
    print("")
    if opcion == 1:
        grupos.append(opcion1())
        seguirMenu = True
    elif opcion == 2:
        ciudades.append(opcion2())
        seguirMenu = True
    elif opcion == 3:
        opcion3()
        seguirMenu = True
    elif opcion == 4:
        opcion4()
        seguirMenu = True
    elif opcion == 5:
        opcion5()
        seguirMenu = True
    elif opcion == 6:
        opcion6()
        seguirMenu = True
    elif opcion == 7:
        seguirMenu = False
        print("Saliendo...")